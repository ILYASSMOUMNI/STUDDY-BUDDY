# frontend/design_system.py
# Design tokens extracted directly from the reference screenshots

import streamlit as st

C = {
    # Layout
    "bg":           "#F0F1F5",   # cool light gray page background
    "surface":      "#FFFFFF",   # card / panel white
    "surface_2":    "#F7F8FA",   # table row hover / subtle bg
    "sidebar_bg":   "#FFFFFF",
    "sidebar_active_bg": "#EEF0FB",
    "sidebar_active_text": "#4B4EDE",

    # Brand indigo (buttons, highlights)
    "indigo":       "#4B4EDE",
    "indigo_dark":  "#3B3EB8",
    "indigo_light": "#EEF0FB",

    # Borders
    "border":       "#E8E9EF",
    "border_dark":  "#D1D3DC",

    # Text
    "text":         "#1A1C23",   # near-black primary
    "text_2":       "#5B5E6E",   # secondary
    "text_3":       "#9496A3",   # tertiary / placeholders
    "text_inv":     "#FFFFFF",

    # Status badges
    "green":        "#1B9E6A",   "green_bg":   "#E8F8F1",
    "orange":       "#D97706",   "orange_bg":  "#FEF3C7",
    "red":          "#DC2626",   "red_bg":     "#FEE2E2",
    "blue":         "#2563EB",   "blue_bg":    "#DBEAFE",
    "purple":       "#7C3AED",   "purple_bg":  "#EDE9FE",
    "gray":         "#5B5E6E",   "gray_bg":    "#F0F1F5",
}


def inject_global_css():
    st.markdown(f"""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

/* ─── Reset ─── */
*, *::before, *::after {{ box-sizing: border-box; margin: 0; }}
html, body, [class*="css"] {{
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    font-size: 14px;
    line-height: 1.5;
    color: {C["text"]};
    -webkit-font-smoothing: antialiased;
}}

/* ─── Page bg ─── */
.stApp {{ background: {C["bg"]}; }}

/* ─── Hide Streamlit chrome ─── */
#MainMenu, footer, header {{ visibility: hidden; height: 0; }}
.block-container {{
    padding: 0 2rem 3rem 2rem !important;
    max-width: 1080px !important;
}}

/* ─── Sidebar ─── */
section[data-testid="stSidebar"] {{
    background: {C["sidebar_bg"]} !important;
    border-right: 1px solid {C["border"]} !important;
    width: 220px !important;
    min-width: 220px !important;
}}
section[data-testid="stSidebar"] > div:first-child {{
    padding: 0 !important;
}}
section[data-testid="stSidebar"] * {{
    color: {C["text_2"]} !important;
}}
/* Sidebar nav buttons */
section[data-testid="stSidebar"] .stButton > button {{
    width: 100% !important;
    background: transparent !important;
    color: {C["text_2"]} !important;
    border: none !important;
    border-radius: 8px !important;
    padding: 9px 14px !important;
    font-size: 0.875rem !important;
    font-weight: 400 !important;
    text-align: left !important;
    box-shadow: none !important;
    transition: background 0.12s, color 0.12s !important;
    justify-content: flex-start !important;
}}
section[data-testid="stSidebar"] .stButton > button:hover {{
    background: {C["indigo_light"]} !important;
    color: {C["indigo"]} !important;
    transform: none !important;
    box-shadow: none !important;
}}

/* ─── Primary buttons ─── */
.stButton > button {{
    background: {C["indigo"]} !important;
    color: #fff !important;
    border: none !important;
    border-radius: 8px !important;
    padding: 8px 18px !important;
    font-family: 'Inter', sans-serif !important;
    font-size: 0.875rem !important;
    font-weight: 500 !important;
    cursor: pointer !important;
    transition: background 0.12s, box-shadow 0.12s, transform 0.08s !important;
    box-shadow: 0 1px 3px rgba(75,78,222,0.25) !important;
    white-space: nowrap !important;
}}
.stButton > button:hover {{
    background: {C["indigo_dark"]} !important;
    box-shadow: 0 3px 10px rgba(75,78,222,0.35) !important;
    transform: translateY(-1px) !important;
}}
.stButton > button:active {{
    transform: translateY(0) !important;
}}
.stButton > button[kind="secondary"] {{
    background: {C["surface"]} !important;
    color: {C["text"]} !important;
    border: 1px solid {C["border"]} !important;
    box-shadow: 0 1px 2px rgba(0,0,0,0.05) !important;
}}
.stButton > button[kind="secondary"]:hover {{
    background: {C["surface_2"]} !important;
    border-color: {C["border_dark"]} !important;
    box-shadow: none !important;
}}

/* ─── Inputs ─── */
.stTextInput label, .stTextArea label, .stSelectbox label,
.stSlider label, .stRadio label p {{
    font-size: 0.8125rem !important;
    font-weight: 500 !important;
    color: {C["text_2"]} !important;
    margin-bottom: 4px !important;
    letter-spacing: 0.01em !important;
}}
.stTextInput > div > div > input {{
    background: {C["surface"]} !important;
    border: 1px solid {C["border"]} !important;
    border-radius: 8px !important;
    color: {C["text"]} !important;
    font-family: 'Inter', sans-serif !important;
    font-size: 0.875rem !important;
    padding: 8px 12px !important;
    height: 38px !important;
    transition: border-color 0.15s, box-shadow 0.15s !important;
}}
.stTextInput > div > div > input:focus {{
    border-color: {C["indigo"]} !important;
    box-shadow: 0 0 0 3px rgba(75,78,222,0.12) !important;
    outline: none !important;
}}
.stTextInput > div > div > input::placeholder {{
    color: {C["text_3"]} !important;
}}
.stTextArea > div > div > textarea {{
    background: {C["surface"]} !important;
    border: 1px solid {C["border"]} !important;
    border-radius: 8px !important;
    color: {C["text"]} !important;
    font-family: 'Inter', sans-serif !important;
    font-size: 0.875rem !important;
    transition: border-color 0.15s, box-shadow 0.15s !important;
}}
.stTextArea > div > div > textarea:focus {{
    border-color: {C["indigo"]} !important;
    box-shadow: 0 0 0 3px rgba(75,78,222,0.12) !important;
}}

/* ─── Selectbox ─── */
.stSelectbox > div > div {{
    background: {C["surface"]} !important;
    border: 1px solid {C["border"]} !important;
    border-radius: 8px !important;
    color: {C["text"]} !important;
    font-size: 0.875rem !important;
    min-height: 38px !important;
}}

/* ─── Radio ─── */
.stRadio > div {{ gap: 6px !important; }}
.stRadio > div > label {{
    background: {C["surface"]} !important;
    border: 1px solid {C["border"]} !important;
    border-radius: 8px !important;
    padding: 9px 14px !important;
    cursor: pointer !important;
    transition: border-color 0.12s, background 0.12s !important;
    font-size: 0.875rem !important;
    color: {C["text"]} !important;
    width: 100% !important;
}}
.stRadio > div > label:hover {{
    border-color: {C["indigo"]} !important;
    background: {C["indigo_light"]} !important;
}}

/* ─── Slider ─── */
.stSlider > div > div > div > div {{
    background: {C["indigo"]} !important;
}}

/* ─── Tabs ─── */
.stTabs [data-baseweb="tab-list"] {{
    background: transparent !important;
    border-bottom: 1px solid {C["border"]} !important;
    gap: 0 !important;
    padding: 0 !important;
}}
.stTabs [data-baseweb="tab"] {{
    background: transparent !important;
    border: none !important;
    border-bottom: 2px solid transparent !important;
    padding: 10px 20px !important;
    font-size: 0.875rem !important;
    font-weight: 500 !important;
    color: {C["text_2"]} !important;
    margin-bottom: -1px !important;
    transition: color 0.12s !important;
}}
.stTabs [aria-selected="true"] {{
    color: {C["indigo"]} !important;
    border-bottom-color: {C["indigo"]} !important;
}}
.stTabs [data-baseweb="tab-panel"] {{
    padding: 24px 0 0 !important;
}}

/* ─── Progress ─── */
.stProgress > div > div {{
    background: {C["border"]} !important;
    border-radius: 100px !important;
    height: 4px !important;
}}
.stProgress > div > div > div {{
    background: {C["indigo"]} !important;
    border-radius: 100px !important;
    height: 4px !important;
}}

/* ─── Expander ─── */
details summary {{
    background: {C["surface"]} !important;
    border: 1px solid {C["border"]} !important;
    border-radius: 8px !important;
    padding: 10px 14px !important;
    font-size: 0.875rem !important;
    font-weight: 500 !important;
    color: {C["text"]} !important;
    cursor: pointer !important;
}}

/* ─── Dataframe ─── */
.stDataFrame {{
    border: 1px solid {C["border"]} !important;
    border-radius: 10px !important;
    overflow: hidden !important;
}}
.stDataFrame table {{ font-size: 0.875rem !important; }}

/* ─── Scrollbar ─── */
::-webkit-scrollbar {{ width: 5px; height: 5px; }}
::-webkit-scrollbar-track {{ background: transparent; }}
::-webkit-scrollbar-thumb {{ background: {C["border_dark"]}; border-radius: 3px; }}

/* ─── Divider ─── */
hr {{
    border: none !important;
    border-top: 1px solid {C["border"]} !important;
    margin: 20px 0 !important;
}}
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────
#  COMPONENT PRIMITIVES
# ─────────────────────────────────────────────────────────────

def page_title(title: str, subtitle: str = ""):
    sub = f'<p style="font-size:0.875rem;color:{C["text_2"]};margin-top:4px;">{subtitle}</p>' if subtitle else ""
    st.markdown(f"""
<div style="padding:28px 0 20px;">
    <h1 style="font-size:1.375rem;font-weight:600;color:{C["text"]};
               letter-spacing:-0.02em;line-height:1.2;">{title}</h1>
    {sub}
</div>""", unsafe_allow_html=True)


def section_heading(text: str):
    st.markdown(f"""
<p style="font-size:0.75rem;font-weight:600;letter-spacing:0.08em;
          text-transform:uppercase;color:{C["text_3"]};
          margin:20px 0 10px;">{text}</p>""", unsafe_allow_html=True)


def kpi_card(value: str, label: str, delta: str = "", delta_positive: bool = True,
             accent_color: str = None):
    accent = accent_color or C["indigo"]
    delta_color = C["green"] if delta_positive else C["red"]
    delta_html = f'<span style="font-size:0.75rem;font-weight:500;color:{delta_color};margin-left:6px;">{delta}</span>' if delta else ""
    st.markdown(f"""
<div style="background:{C["surface"]};border:1px solid {C["border"]};
            border-radius:12px;padding:20px 22px;
            box-shadow:0 1px 3px rgba(0,0,0,0.04);">
    <p style="font-size:0.75rem;font-weight:600;letter-spacing:0.07em;
              text-transform:uppercase;color:{C["text_3"]};margin-bottom:10px;">
        {label}
    </p>
    <div style="display:flex;align-items:baseline;gap:4px;">
        <span style="font-size:1.875rem;font-weight:700;
                     color:{C["text"]};letter-spacing:-0.03em;
                     font-family:'Inter',sans-serif;line-height:1;">
            {value}
        </span>
        {delta_html}
    </div>
    <div style="margin-top:12px;height:3px;border-radius:100px;
                background:{accent};opacity:0.8;"></div>
</div>""", unsafe_allow_html=True)


def badge(text: str, color: str = "gray"):
    """color: green | orange | red | blue | purple | indigo | gray"""
    palettes = {
        "green":  (C["green"],  C["green_bg"]),
        "orange": (C["orange"], C["orange_bg"]),
        "red":    (C["red"],    C["red_bg"]),
        "blue":   (C["blue"],   C["blue_bg"]),
        "purple": (C["purple"], C["purple_bg"]),
        "indigo": (C["indigo"], C["indigo_light"]),
        "gray":   (C["gray"],   C["gray_bg"]),
    }
    fg, bg = palettes.get(color, palettes["gray"])
    return (f'<span style="display:inline-block;padding:3px 10px;'
            f'border-radius:100px;font-size:0.72rem;font-weight:600;'
            f'letter-spacing:0.03em;background:{bg};color:{fg};">'
            f'{text}</span>')


def card(content_html: str, padding: str = "20px 24px", extra_style: str = ""):
    st.markdown(f"""
<div style="background:{C["surface"]};border:1px solid {C["border"]};
            border-radius:12px;padding:{padding};
            box-shadow:0 1px 3px rgba(0,0,0,0.04);{extra_style}">
    {content_html}
</div>""", unsafe_allow_html=True)


def inline_alert(text: str, kind: str = "info"):
    styles = {
        "info":    (C["indigo"], C["indigo_light"], "#C7D2FE"),
        "success": (C["green"],  C["green_bg"],     "#A7F3D0"),
        "warning": (C["orange"], C["orange_bg"],    "#FDE68A"),
        "danger":  (C["red"],    C["red_bg"],       "#FCA5A5"),
    }
    fg, bg, border = styles.get(kind, styles["info"])
    st.markdown(f"""
<div style="background:{bg};border:1px solid {border};border-radius:8px;
            padding:10px 14px;font-size:0.875rem;color:{fg};line-height:1.5;
            margin-bottom:12px;">{text}</div>""", unsafe_allow_html=True)


def spacer(h: int = 16):
    st.markdown(f'<div style="height:{h}px;"></div>', unsafe_allow_html=True)


def divider():
    st.markdown(f'<hr style="border:none;border-top:1px solid {C["border"]};margin:16px 0;">', unsafe_allow_html=True)


def table_header(cols: list):
    """cols: list of (label, flex_width) tuples"""
    cells = "".join(
        f'<div style="flex:{w};font-size:0.72rem;font-weight:600;'
        f'letter-spacing:0.08em;text-transform:uppercase;color:{C["text_3"]};">'
        f'{lbl}</div>'
        for lbl, w in cols
    )
    st.markdown(f"""
<div style="display:flex;gap:12px;padding:8px 16px;
            border-bottom:1px solid {C["border"]};
            background:{C["surface_2"]};
            border-radius:10px 10px 0 0;">
    {cells}
</div>""", unsafe_allow_html=True)
