# frontend/page_home.py
# Layout mirrors screenshot 1: KPI row, 2-col content, activity panel

import streamlit as st
from backend.database import get_student_stats, get_weaknesses, get_all_courses
from frontend.design_system import C, page_title, kpi_card, badge, card, spacer, divider, inline_alert


def render_home():
    stats   = get_student_stats(st.session_state.student_id)
    weak    = get_weaknesses(st.session_state.student_id)
    courses = get_all_courses()
    name    = st.session_state.student_name

    # ── Page title ────────────────────────────────────────────
    col_title, col_btn = st.columns([4, 1])
    with col_title:
        page_title(f"Dashboard", f"Welcome back, {name}. Here's your learning summary.")
    with col_btn:
        spacer(28)
        if st.button("+ Upload course", type="primary"):
            st.session_state.current_page = "courses"
            st.rerun()

    # ── KPI row ───────────────────────────────────────────────
    k1, k2, k3, k4 = st.columns(4)
    score = stats["score_global"]
    s_color = C["green"] if score >= 70 else C["orange"] if score >= 50 else C["red"]
    s_delta_pos = score >= 70

    with k1: kpi_card(str(len(courses)), "Total courses", accent_color=C["indigo"])
    with k2: kpi_card(str(stats["total_questions"]), "Questions answered", accent_color=C["blue"])
    with k3: kpi_card(f"{score}%", "Global score",
                      delta=("+good" if score >= 70 else "needs work"),
                      delta_positive=s_delta_pos, accent_color=s_color)
    with k4: kpi_card(str(len(weak)), "Weak concepts",
                      accent_color=C["red"] if weak else C["green"])

    spacer(24)

    # ── Main content + right panel ────────────────────────────
    col_main, col_right = st.columns([2.4, 1], gap="large")

    with col_main:
        # Active courses panel
        st.markdown(f"""
<div style="background:{C["surface"]};border:1px solid {C["border"]};
            border-radius:12px;overflow:hidden;
            box-shadow:0 1px 3px rgba(0,0,0,0.04);">
    <div style="display:flex;align-items:center;justify-content:space-between;
                padding:16px 20px;border-bottom:1px solid {C["border"]};">
        <span style="font-size:0.9375rem;font-weight:600;color:{C["text"]};">
            Active courses
        </span>
    </div>
""", unsafe_allow_html=True)

        if not courses:
            st.markdown(f"""
<div style="padding:32px 20px;text-align:center;color:{C["text_3"]};
            font-size:0.875rem;">
    No courses indexed yet. Upload your first course to get started.
</div>""", unsafe_allow_html=True)
        else:
            for i, course in enumerate(courses[:5]):
                sep = f"border-top:1px solid {C['border']};" if i > 0 else ""
                # fake progress for visual completeness
                chunks = course["num_chunks"]
                pct = min(100, int((chunks / max(chunks, 20)) * 100))

                st.markdown(f"""
<div style="padding:14px 20px;{sep}display:flex;
            align-items:center;justify-content:space-between;gap:16px;">
    <div style="flex:1;min-width:0;">
        <div style="font-weight:500;font-size:0.875rem;
                    color:{C["text"]};margin-bottom:2px;
                    white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
            {course['title']}
        </div>
        <div style="font-size:0.75rem;color:{C["text_3"]};">
            {chunks} segments indexed
        </div>
        <div style="margin-top:8px;height:3px;border-radius:100px;
                    background:{C["border"]};overflow:hidden;">
            <div style="height:3px;width:{pct}%;background:{C["indigo"]};
                        border-radius:100px;"></div>
        </div>
    </div>
</div>""", unsafe_allow_html=True)

                ca, cb, _ = st.columns([1, 1, 2])
                with ca:
                    if st.button("Chat", key=f"hc_{course['id']}",
                                 use_container_width=True, type="secondary"):
                        st.session_state.selected_course_id = course["id"]
                        st.session_state.current_page = "chat"
                        st.session_state.chat_messages = []
                        st.session_state.chat_display  = []
                        st.rerun()
                with cb:
                    if st.button("Quiz", key=f"hq_{course['id']}",
                                 use_container_width=True, type="secondary"):
                        st.session_state.selected_course_id = course["id"]
                        st.session_state.current_page = "quiz"
                        st.rerun()
                spacer(4)

        st.markdown("</div>", unsafe_allow_html=True)

        spacer(20)

        # How it works row
        st.markdown(f"""
<p style="font-size:0.75rem;font-weight:600;letter-spacing:0.08em;
          text-transform:uppercase;color:{C["text_3"]};margin-bottom:12px;">
    How it works
</p>""", unsafe_allow_html=True)

        s1, s2, s3, s4 = st.columns(4)
        steps = [
            ("01", "Upload", "PDF or DOCX course materials"),
            ("02", "Chat",   "Ask the AI tutor anything"),
            ("03", "Quiz",   "Test your understanding"),
            ("04", "Review", "Target your weak spots"),
        ]
        for col, (num, title, desc) in zip([s1, s2, s3, s4], steps):
            with col:
                st.markdown(f"""
<div style="background:{C["surface"]};border:1px solid {C["border"]};
            border-radius:10px;padding:16px;height:100px;">
    <div style="font-family:'JetBrains Mono',monospace;font-size:0.7rem;
                color:{C["indigo"]};margin-bottom:8px;font-weight:500;">
        {num}
    </div>
    <div style="font-weight:600;font-size:0.8125rem;
                color:{C["text"]};margin-bottom:4px;">{title}</div>
    <div style="font-size:0.75rem;color:{C["text_3"]};line-height:1.4;">{desc}</div>
</div>""", unsafe_allow_html=True)

    with col_right:
        # Weak concepts panel (like "Recent Activity" in screenshot)
        st.markdown(f"""
<div style="background:{C["surface"]};border:1px solid {C["border"]};
            border-radius:12px;overflow:hidden;
            box-shadow:0 1px 3px rgba(0,0,0,0.04);">
    <div style="padding:16px 18px;border-bottom:1px solid {C["border"]};">
        <span style="font-size:0.9375rem;font-weight:600;color:{C["text"]};">
            Weak concepts
        </span>
    </div>
""", unsafe_allow_html=True)

        if not weak:
            st.markdown(f"""
<div style="padding:24px 18px;text-align:center;">
    {badge("All good", "green")}
    <p style="font-size:0.8rem;color:{C["text_3"]};margin-top:10px;line-height:1.5;">
        No weak concepts detected.<br>Complete a quiz to get feedback.
    </p>
</div>""", unsafe_allow_html=True)
        else:
            for w in weak[:7]:
                color = "red" if w["fail_count"] >= 3 else "orange" if w["fail_count"] >= 2 else "gray"
                st.markdown(f"""
<div style="padding:10px 18px;border-bottom:1px solid {C["border"]};
            display:flex;align-items:center;justify-content:space-between;">
    <span style="font-size:0.8125rem;color:{C["text"]};font-weight:500;">
        {w["concept"]}
    </span>
    {badge(f'{w["fail_count"]}x', color)}
</div>""", unsafe_allow_html=True)

        st.markdown("</div>", unsafe_allow_html=True)

        spacer(16)
        if weak:
            if st.button("Start targeted quiz", use_container_width=True, type="primary"):
                st.session_state.current_page = "quiz"
                st.rerun()

        spacer(16)

        # Score summary card (like "Workload Balance" in screenshot)
        score_color = C["green"] if score >= 70 else C["orange"] if score >= 50 else C["red"]
        verdict = "Strong" if score >= 70 else "Developing" if score >= 50 else "Needs work"
        st.markdown(f"""
<div style="background:{C["indigo"]};border-radius:12px;
            padding:20px 18px;color:#fff;">
    <p style="font-size:0.72rem;font-weight:600;letter-spacing:0.08em;
              text-transform:uppercase;opacity:0.7;margin-bottom:8px;">
        Overall performance
    </p>
    <p style="font-size:1.5rem;font-weight:700;letter-spacing:-0.02em;
              margin-bottom:4px;">{verdict}</p>
    <p style="font-size:0.8rem;opacity:0.75;">
        {stats['correct_answers']} correct / {stats['total_questions']} total questions
    </p>
    <div style="margin-top:16px;height:3px;border-radius:100px;
                background:rgba(255,255,255,0.2);">
        <div style="width:{score}%;height:3px;border-radius:100px;
                    background:#fff;"></div>
    </div>
    <p style="font-size:0.7rem;opacity:0.6;margin-top:6px;">
        {score}% success rate
    </p>
</div>""", unsafe_allow_html=True)
