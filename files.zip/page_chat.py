# frontend/page_chat.py

import streamlit as st
from backend.database import get_all_courses
from backend.ai_tutor import chat_with_tutor, explain_concept_step_by_step
from frontend.design_system import C, page_title, spacer, divider, badge


def render_chat():
    courses = get_all_courses()
    if not courses:
        page_title("Chat assistant")
        st.markdown(f"""
<div style="padding:32px;text-align:center;color:{C["text_3"]};">
    No courses available. Upload a course first.
</div>""", unsafe_allow_html=True)
        if st.button("Upload course", type="primary"):
            st.session_state.current_page = "courses"
            st.rerun()
        return

    # ── Top bar ───────────────────────────────────────────────
    col_title, col_select, col_btn = st.columns([2, 2, 1])
    with col_title:
        page_title("Chat assistant", "Ask anything about your course.")
    with col_select:
        spacer(30)
        course_map = {c["title"]: c["id"] for c in courses}
        default_idx = 0
        if st.session_state.selected_course_id:
            for i, c in enumerate(courses):
                if c["id"] == st.session_state.selected_course_id:
                    default_idx = i; break
        sel = st.selectbox("Course", list(course_map.keys()),
                           index=default_idx, label_visibility="collapsed")
        st.session_state.selected_course_id = course_map[sel]
    with col_btn:
        spacer(30)
        if st.button("Clear chat", type="secondary", use_container_width=True):
            st.session_state.chat_messages = []
            st.session_state.chat_display  = []
            st.rerun()

    # ── Suggestions (empty state) ─────────────────────────────
    if not st.session_state.chat_display:
        suggestions = [
            "Explain neural networks step by step",
            "Supervised vs unsupervised learning?",
            "How does backpropagation work?",
            "What is gradient descent?",
            "Explain overfitting and how to avoid it",
            "What is a transformer model?",
        ]
        st.markdown(f"""
<div style="background:{C["surface"]};border:1px solid {C["border"]};
            border-radius:12px;padding:20px 24px;margin-bottom:16px;">
    <p style="font-size:0.72rem;font-weight:600;letter-spacing:0.08em;
              text-transform:uppercase;color:{C["text_3"]};margin-bottom:14px;">
        Suggested questions
    </p>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;">
""", unsafe_allow_html=True)

        cols = st.columns(3)
        for i, s in enumerate(suggestions):
            with cols[i % 3]:
                st.markdown(f"""
<div style="background:{C["surface_2"]};border:1px solid {C["border"]};
            border-radius:8px;padding:10px 12px;margin-bottom:4px;
            font-size:0.8125rem;color:{C["text_2"]};line-height:1.4;
            cursor:pointer;">
    {s}
</div>""", unsafe_allow_html=True)
                if st.button("Ask", key=f"s_{i}", use_container_width=True,
                             type="secondary"):
                    _send(s, st.session_state.selected_course_id)

        st.markdown("</div></div>", unsafe_allow_html=True)

    # ── Message thread ────────────────────────────────────────
    if st.session_state.chat_display:
        thread_html = ""
        for msg in st.session_state.chat_display:
            if msg["role"] == "user":
                thread_html += f"""
<div style="display:flex;justify-content:flex-end;margin:12px 0;">
    <div style="max-width:68%;">
        <div style="font-size:0.68rem;font-weight:600;letter-spacing:0.06em;
                    text-transform:uppercase;color:{C["text_3"]};
                    text-align:right;margin-bottom:4px;">You</div>
        <div style="background:{C["indigo"]};color:#fff;
                    border-radius:16px 16px 4px 16px;
                    padding:10px 16px;font-size:0.875rem;line-height:1.55;">
            {msg['content']}
        </div>
    </div>
</div>"""
            else:
                content = msg["content"].replace("\n\n", "<br><br>").replace("\n", "<br>")
                thread_html += f"""
<div style="display:flex;justify-content:flex-start;margin:12px 0;">
    <div style="max-width:78%;">
        <div style="font-size:0.68rem;font-weight:600;letter-spacing:0.06em;
                    text-transform:uppercase;color:{C["indigo"]};
                    margin-bottom:4px;">StudyBuddy</div>
        <div style="background:{C["surface"]};border:1px solid {C["border"]};
                    color:{C["text"]};border-radius:16px 16px 16px 4px;
                    padding:10px 16px;font-size:0.875rem;line-height:1.6;">
            {content}
        </div>
    </div>
</div>"""

        st.markdown(f"""
<div style="background:{C["surface_2"]};border:1px solid {C["border"]};
            border-radius:12px;padding:16px 20px;
            max-height:460px;overflow-y:auto;margin-bottom:12px;">
    {thread_html}
</div>""", unsafe_allow_html=True)

    # ── Input bar ─────────────────────────────────────────────
    st.markdown(f"""
<div style="background:{C["surface"]};border:1px solid {C["border"]};
            border-radius:12px;padding:14px 18px;">
""", unsafe_allow_html=True)

    c_inp, c_send = st.columns([6, 1])
    with c_inp:
        user_input = st.text_input(
            "msg", placeholder="Ask a question about your course…",
            label_visibility="collapsed", key="chat_input_v3"
        )
    with c_send:
        spacer(2)
        send = st.button("Send", type="primary", use_container_width=True)

    st.markdown("</div>", unsafe_allow_html=True)

    if send and user_input.strip():
        _send(user_input.strip(), st.session_state.selected_course_id)

    # ── Step-by-step panel ────────────────────────────────────
    spacer(8)
    with st.expander("Step-by-step explanation"):
        c_concept, c_level = st.columns(2)
        with c_concept:
            concept = st.text_input("Concept",
                placeholder="E.g. Attention mechanism, K-means…",
                key="deep_c")
        with c_level:
            level = st.select_slider("Level",
                options=["beginner", "intermediate", "advanced"],
                value="intermediate")
        if st.button("Generate", type="primary"):
            if concept.strip():
                with st.spinner("Generating explanation…"):
                    res = explain_concept_step_by_step(
                        st.session_state.selected_course_id,
                        concept.strip(), student_level=level)
                st.markdown(res)


def _send(msg: str, course_id: int):
    st.session_state.chat_display.append({"role": "user", "content": msg})
    st.session_state.chat_messages.append({"role": "user", "content": msg})
    with st.spinner(""):
        try:
            resp = chat_with_tutor(
                messages=st.session_state.chat_messages[:-1],
                course_id=course_id,
                user_message=msg)
            st.session_state.chat_display.append({"role": "assistant", "content": resp})
            st.session_state.chat_messages.append({"role": "assistant", "content": resp})
        except Exception as e:
            err = f"Error: {e}"
            st.session_state.chat_display.append({"role": "assistant", "content": err})
    st.rerun()
