# app.py

import streamlit as st
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from backend.database import init_db
from frontend.design_system import inject_global_css, C

st.set_page_config(
    page_title="StudyBuddy",
    page_icon=None,
    layout="wide",
    initial_sidebar_state="expanded"
)
init_db()
inject_global_css()

_DEFAULTS = {
    "student_id":            None,
    "student_name":          None,
    "student_email":         None,
    "current_page":          "home",
    "selected_course_id":    None,
    "chat_messages":         [],
    "chat_display":          [],
    "quiz_data":             None,
    "quiz_answers":          {},
    "quiz_submitted":        False,
    "wrong_answers_session": [],
}
for k, v in _DEFAULTS.items():
    if k not in st.session_state:
        st.session_state[k] = v


NAV_ITEMS = [
    ("home",      "Dashboard"),
    ("courses",   "Courses"),
    ("chat",      "Chat assistant"),
    ("quiz",      "Quiz"),
    ("dashboard", "Analytics"),
]


def _sidebar():
    with st.sidebar:
        # ── Brand ──
        st.markdown(f"""
<div style="padding:24px 20px 16px;">
    <div style="display:flex;align-items:center;gap:10px;">
        <div style="width:32px;height:32px;background:{C["indigo"]};
                    border-radius:8px;display:flex;align-items:center;
                    justify-content:center;">
            <span style="color:#fff;font-size:0.9rem;font-weight:700;">S</span>
        </div>
        <div>
            <div style="font-size:0.9375rem;font-weight:600;
                        color:{C["text"]};letter-spacing:-0.01em;">
                StudyBuddy
            </div>
            <div style="font-size:0.7rem;color:{C["text_3"]};margin-top:1px;">
                IA & Data Science
            </div>
        </div>
    </div>
</div>
<div style="height:1px;background:{C["border"]};margin:0 0 8px;"></div>
""", unsafe_allow_html=True)

        if not st.session_state.student_id:
            return

        # ── Nav ──
        for page_id, label in NAV_ITEMS:
            is_active = st.session_state.current_page == page_id
            if is_active:
                st.markdown(f"""
<style>
#nav-wrap-{page_id} button {{
    background: {C["indigo_light"]} !important;
    color: {C["indigo"]} !important;
    font-weight: 600 !important;
}}
</style>""", unsafe_allow_html=True)
            st.markdown(f'<div id="nav-wrap-{page_id}">', unsafe_allow_html=True)
            if st.button(label, key=f"nav_{page_id}", use_container_width=True):
                st.session_state.current_page = page_id
                st.rerun()
            st.markdown("</div>", unsafe_allow_html=True)

        # ── Bottom: user + logout ──
        st.markdown(f"""
<div style="position:fixed;bottom:0;left:0;width:220px;
            border-top:1px solid {C["border"]};
            background:{C["surface"]};padding:12px 16px;">
    <div style="font-size:0.8125rem;font-weight:500;
                color:{C["text"]};">
        {st.session_state.student_name or ""}
    </div>
    <div style="font-size:0.72rem;color:{C["text_3"]};margin-top:1px;">
        {st.session_state.student_email or ""}
    </div>
</div>
""", unsafe_allow_html=True)

        st.markdown('<div style="height:56px;"></div>', unsafe_allow_html=True)
        if st.button("Sign out", key="signout", use_container_width=True,
                     type="secondary"):
            for k in list(st.session_state.keys()):
                del st.session_state[k]
            for k, v in _DEFAULTS.items():
                st.session_state[k] = v
            st.rerun()


def main():
    _sidebar()

    if not st.session_state.student_id:
        from frontend.page_login import render_login
        render_login()
        return

    page = st.session_state.current_page
    if page == "home":
        from frontend.page_home import render_home; render_home()
    elif page == "courses":
        from frontend.page_courses import render_courses; render_courses()
    elif page == "chat":
        from frontend.page_chat import render_chat; render_chat()
    elif page == "quiz":
        from frontend.page_quiz import render_quiz; render_quiz()
    elif page == "dashboard":
        from frontend.page_dashboard import render_dashboard; render_dashboard()
    else:
        from frontend.page_home import render_home; render_home()


if __name__ == "__main__":
    main()
